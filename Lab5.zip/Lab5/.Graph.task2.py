class Graph:
    def __init__(self,V):
       self.V=V
       self.adj=[[] for _ in range(V)]
    def add_edge(self,v,w):
        self.adj[v].append(w)
    def bfs(self,s):
        visited=[False]*self.V
        queue=[]
        visited[s]=True
        queue.append(s)
        while queue:
            s=queue.pop(0)
            print(s,end="")
            for i in self.adj[s]:
                if not visited[i]:
                    visited[i]=True
                    queue.append(i)
        print()
class TGraph:
    def __init__(self):
        self.adj={}
    def add_edge(self,v,w):
        if v not in self.adj:
            self.adj[v]=[]
        if w not in self.adj:
            self.adj[w]=[]
        self.adj[v].append(w)
    def bfs(self,start,goal):
        visited={start}
        queue=[start]
        while queue:
            v=queue.pop(0)
            print(v,end="")
            if v==goal:
                print(goal)
                return 
            for w in self.adj[v]:
                if w not in visited:
                    visited.add(w)
                    queue.append(w)
        
g=Graph(4)
g.add_edge(0,1)
g.add_edge(0,2)
g.add_edge(1,2)
g.add_edge(2,0)
g.add_edge(2,3)
g.add_edge(3,3)
print(g.bfs(2)) 
g1=TGraph()
g1.add_edge('A','B')  
g1.add_edge('A','F') 
g1.add_edge('A','D') 
g1.add_edge('A','E') 
g1.add_edge('B','K') 
g1.add_edge('B','J') 
g1.add_edge('D','G') 
g1.add_edge('E','C') 
g1.add_edge('E','H') 
g1.add_edge('E','I') 
g1.add_edge('K','N') 
g1.add_edge('K','M') 
g1.add_edge('I','L') 
g1.bfs('A','G')