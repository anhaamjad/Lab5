class Graph:
    def __init__(self,V):
       self.V=V
       self.adj=[[] for _ in range(V)]
    def add_edge(self,v,w):
        self.adj[v].append(w)
    def add_undedge(self,v,w):
        self.adj[v].append(w)
        self.adj[w].append(v)
    def print(self):
       for node in range(self.V):
          print(node,"->",self.adj[node])
    def bfs(self,s):
        visited=[False]*self.V
        queue=[]
        visited[s]=True
        queue.append(s)
        while queue:
            s=queue.pop(0)
            print(s,end="")
            for i in self.adj[s]:
                if not visited[i]:
                    visited[i]=True
                    queue.append(i)
        print()
g=Graph(4)
g.add_edge(0,1)
g.add_edge(0,2)
g.add_edge(1,2)
g.add_edge(2,0)
g.add_edge(2,3)
g.add_edge(3,3)
print(g.bfs(2)) 
g1=Graph(5)
g1.add_undedge(0,1)  
g1.add_undedge(0,4) 
g1.add_undedge(1,2) 
g1.add_undedge(1,3) 
g1.add_undedge(1,4) 
g1.add_undedge(2,3) 
g1.add_undedge(3,4) 
g1.print()
g1.bfs(0)